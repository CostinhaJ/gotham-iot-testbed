"""
train_model_example.py
-----------------------
Scaffold de treino, so para mostrar o formato esperado pelo classifier.py.
Adapta isto ao TEU codigo de modelo (troca o RandomForestClassifier pelo
teu modelo, mantem so a mesma ordem de features e o mesmo joblib.dump no
fim).

Formato de entrada esperado: um CSV com uma coluna por feature em
FEATURE_NAMES + uma coluna "label" (0 = benigno, 1 = malicioso).

Exemplo de fontes de dados possiveis:
  - Trafego capturado na tua propria topologia GNS3 (tcpdump/wireshark nos
    links, depois convertido para estas features, por exemplo com
    CICFlowMeter).
  - Datasets publicos como NSL-KDD ou CICIDS2017 (tens de mapear as
    colunas deles para FEATURE_NAMES, ou simplesmente mudar FEATURE_NAMES
    em classifier.py para bater certo com o dataset escolhido -- o
    controlador so precisa que as duas listas estejam alinhadas).

Uso:
    python train_model_example.py dados.csv
"""

import sys

import joblib
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report

from classifier import FEATURE_NAMES, DEFAULT_MODEL_PATH


def main(csv_path):
    df = pd.read_csv(csv_path)

    missing = [c for c in FEATURE_NAMES if c not in df.columns]
    if missing:
        raise ValueError(
            f"O CSV nao tem as colunas {missing}. Ajusta FEATURE_NAMES em "
            f"classifier.py ou o teu CSV para estarem alinhados."
        )

    X = df[FEATURE_NAMES]
    y = df["label"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    # --- Substitui isto pelo teu modelo/pipeline real ---
    model = RandomForestClassifier(n_estimators=200, random_state=42, class_weight="balanced")
    model.fit(X_train, y_train)
    # -----------------------------------------------------

    y_pred = model.predict(X_test)
    print(classification_report(y_test, y_pred, target_names=["benigno", "malicioso"]))

    joblib.dump(model, DEFAULT_MODEL_PATH)
    print(f"Modelo guardado em: {DEFAULT_MODEL_PATH}")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Uso: python train_model_example.py <dados.csv>")
        sys.exit(1)
    main(sys.argv[1])
